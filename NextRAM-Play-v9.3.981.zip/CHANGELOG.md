## NextRAM Play Fix 9.3.981

[CODE OPTIMIZATION]
- Added pre-write verification for all file operations
- Replaced all backticks (`) with $() for POSIX shell compatibility
- Added fallback mechanisms for unavailable functions
- Enhanced logging for better troubleshooting
- Added path availability checks before usage
- Expanded support for various GPU/CPU paths across different chipsets
- Replaced all &>/dev/null with 2>/dev/null for compatibility
- Added file and directory permission checks
- Optimized loops and conditional operators
- Fixed potential compatibility issues with Magisk Alpha
- Improved error handling for swap mounting operations
- Added safe ZRAM reset operations
- Enhanced root permission checking for different Android versions
- Fixed potential deadlocks in configuration handling
- Added timeouts for critical operations
- Improved compatibility with different firmwares and kernels

[PLAY MODE IMPROVEMENTS]
- Added alternative GPU control paths (Adreno, Mali, Generic)
- Enhanced CPU/GPU path availability checking system
- Added safe CPU frequency modification operations
- Improved error handling in game detector
- Optimized thermal zone management

[MEMORY MANAGEMENT]
- Enhanced ZRAM operation safety
- Added additional checks before ZRAM reset
- Optimized ZRAM size calculation
- Improved compression stream handling
___
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
___

## NextRAM Play v9.3.978-(93978)

[PLAY MODE]
- Added NextRAM Play gaming mode for enhanced in-game performance
- Added CPU optimization: governor control, min/max frequency management, boost mode
- Added GPU optimization: governor tuning, frequency control, throttling disable
- Enhanced touch responsiveness: increased polling rate, VSync configuration
- Added network tuning for gaming: TCP optimization, buffer management, WiFi power save disable
- Added memory optimization: swappiness tuning, cache pressure control, ZRAM management
- Added thermal management: profile selection (aggressive, balanced, conservative)
- Added background process control for resource optimization
- Added game detector for automatic gaming mode activation
- Added gaming profiles: FPS Competitive, Open World, Casual, Battery Saver, Custom
- Added performance monitor

[INSTALL]
- Fixed Play Mode installation on some devices
- Improved compatibility with various kernel manufacturers
- Fixed timeouts during configuration application

[CTL]
- update NextRAM CTL Service
---
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
---

## NextRAM Whole Fix 9.2.822

[APP]
- bug fixes
___
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
___

## NextRAM Whole v9.2.371-(92371)

**[APP]**
- added the material you theme
- added liquid glass
- added a map with information about the module
- added a function to turn on/off the module
- added import/export of configurations
- changed the themes
- fixed the recording of configurations from the history
- added NextRAM Store
- fixed small bugs

**[INSTALL]**
- fixed an issue with installing the app
- fixed time-out
___
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
___

## NextRAM Fusion v9.1.280-(91280)

**[CODE OPTIMIZATION]**
- Enhanced file permission verification before writing kernel parameters
- Added comprehensive file and directory existence checks
- Optimized error handling routines throughout all scripts
- Streamlined loop structures and conditional statements
- Improved code maintainability while preserving original functionality

**[STABILITY ENHANCEMENTS]**
- Fixed potentially unsafe script constructs
- Added thorough system utility availability validation
- Enhanced device compatibility across different Android implementations
- Improved swap file creation error handling
- Strengthened file access permission verifications

**[ZRAM IMPROVEMENTS]**
- Advanced zram device detection with dual-path checking
- Added safety checks before zram reset operations
- Enhanced compression algorithm selection error handling
- Implemented /sys/block/zram0 directory validation
- Refined compression stream parameter management

**[KERNEL TUNING SYSTEM]**
- Upgraded kernel parameter application with verification layer
- Implemented comprehensive tuning success monitoring
- Enhanced dynamic swappiness algorithm with multi-factor calculations
- Introduced safe parameter setting functions (set_param, set_sysctl)
- Added write capability verification before file operations

**[PERFORMANCE OPTIMIZATION]**
- Reduced script execution overhead through code refinement
- Minimized redundant file system operations
- Optimized I/O operations during swap configuration
- Enhanced script execution efficiency

**[COMPATIBILITY UPDATES]**
- Expanded Android version and Linux kernel compatibility
- Improved operation on low-resource devices
- Added legacy kernel support checks
- Enhanced filesystem type compatibility

**[API ENHANCEMENTS]**
- Improved web interface stability and responsiveness
- Fixed configuration management edge cases
- Enhanced API command parsing and execution
- Added configuration change validation

**[MONITORING SYSTEM]**
- Upgraded memory and zram monitoring architecture
- Added comprehensive device state verification
- Fixed resource leakage in background monitoring
- Enhanced monitoring process management

___
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
___

## NextRAM v9.0.127(90127)
[INSTALL]
- added time-out when selecting the configuration method
___
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
___

## NextRAM v9.0.000(90000) 
[NRAICF] (beta)
- added the first C++ tool for NextRAM. It generates a configuration for the device

[MAIN]
- major corrections in the code
- added new settings to the configuration file regarding the kernel
- zRAM fixes...

[APK]
- completely updated the interface - Material 3
- switches have been added for new parameters
- improved existing themes
- added new translations: Chinese and Ukrainian
- added help for each parameter with translation
- fixed switching color scheme

[INSTALL]
- update information
- added new logic (NRAICF)

[ACTION]
- fixed the display of nlive and logs
___
Telegram: https://t.me/nextram_official
Web Site: https://nextram.cocal.ru
___

## NextRAM v8.5.638(85638)
[ACTION]
- reworked the logic of the "Action" button in root managers

[APK]
- update NextRAM App - 8.4.201-fix (84201)

[zRAM]
- fix settings - maximum compression streams
- other improvements to the code
___
Telegram: https://t.me/nextram_official
___

## NextRAM v8.4.201-fix(84201)
[KERNEL]
- fix tuning scripts
- fix slowed charge

[zRAM]
- fix zRAM custom size (4G?)
- bugfixes
___
Telegram: https://t.me/nextram_official
___
## NextRAM v8.3.201-pre(83201p)
[INSTALL]

- adding support for older configurations (almost NextRAM 2+) 
- adding new options to the config when they are missing

[MAIN]
 
- fix swapoff options

[KERNEL]

- Smart dynamic swappiness tuning based on memory size, ZRAM usage, and current swap utilization
- Extended memory parameters - min_free_kbytes, watermark_scale_factor, OOM settings
- Dual operation modes - performance (aggressive) and power-saving (balanced)
- Settings verification with success rate checking
- Safe handling - file availability checks before writing
- Detailed logging of each modified parameter
___
Telegram: https://t.me/nextram_official
